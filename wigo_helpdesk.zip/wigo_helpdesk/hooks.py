# -*- coding: utf-8 -*-
from odoo import api, SUPERUSER_ID

PRIORIDADES_DEFAULT = [
    (10, 'Muy Alta',  '#e53935', 24.0,  'Inmediato (30 min. Después de notificación ya se debe estar atendiendo)'),
    (20, 'Alta',      '#f57c00', 72.0,  'Inmediato según orden de prelación'),
    (30, 'Media',     '#fdd835', 72.0,  'Priorizado según orden de prelación'),
    (40, 'Baja',      '#8bc34a', 48.0,  'Priorizado según orden de prelación'),
    (50, 'Crítica',   '#7b0000',  6.0,  'Inmediato (15 min. Después de notificación ya se debe estar atendiendo)'),
]


def post_init_hook(env_or_cr, registry=None):
    """Compat post-init hook (soporta firma nueva env y antigua cr, registry)."""
    if registry is None and hasattr(env_or_cr, 'cr'):
        env = api.Environment(env_or_cr.cr, SUPERUSER_ID, dict(getattr(env_or_cr, 'context', {}) or {}))
    else:
        env = api.Environment(env_or_cr, SUPERUSER_ID, {})

    # ── Limpieza original ────────────────────────────────────────────────────
    escalated_stage = env.ref('wigo_helpdesk.stage_escalated', raise_if_not_found=False)
    waiting_stage = env['helpdesk.stage'].search([('name', '=', 'En Espera')], limit=1)

    if escalated_stage:
        if waiting_stage and escalated_stage.id != waiting_stage.id:
            env['helpdesk.ticket'].sudo().search([('stage_id', '=', escalated_stage.id)]).write({
                'stage_id': waiting_stage.id,
            })
        escalated_stage.sudo().unlink()

    # ── Seed de prioridades SLA ───────────────────────────────────────────────
    config = env['helpdesk.sla.config'].get_config()
    if config and not config.priority_sla_ids:
        for seq, nombre, color, horas, atencion in PRIORIDADES_DEFAULT:
            env['helpdesk.priority.sla'].sudo().create({
                'config_id': config.id,
                'sequence': seq,
                'name': nombre,
                'color': color,
                'hours_limit': horas,
                'attention_time': atencion,
            })
